# Tutorials

![YouTube Art](assets/youtube-art.png?raw=true "Title")

# Support

☕ - [Buy Me a Coffee](https://www.buymeacoffee.com/antonputra)

# Contents

📚 - [Lessons](docs/contents.md)

# Social

🎥 - [YouTube](https://www.youtube.com/c/AntonPutra)  
🎮 - [Discord](https://discord.gg/Wy5SPDSTjX)  
💼 - [LinkedIn](https://www.linkedin.com/in/anton-putra)  
🎙 - [Twitter](https://twitter.com/antonvputra)  
📨 - me@antonputra.com  
