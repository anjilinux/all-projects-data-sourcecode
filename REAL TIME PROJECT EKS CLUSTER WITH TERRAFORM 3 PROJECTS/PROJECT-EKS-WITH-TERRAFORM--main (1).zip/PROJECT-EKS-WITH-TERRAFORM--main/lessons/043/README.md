# How to Create Kubernetes Secrets?

## Create EKS Cluster
```bash
$ eksctl create cluster -f cluster.yaml
```

## Delete EKS Cluster
```bash
$ eksctl delete cluster -f cluster.yaml
```
