# How to Deploy NodeJS App to Kubernetes?

## Create EKS Cluster
```bash
$ eksctl create cluster -f eks.yaml
```

## Delete EKS Cluster
```bash
$ eksctl delete cluster -f eks.yaml
```
