# AWS Session Manager Step by Step Tutorial: SSH | Port-Forward | Audit | Logs

[Step by Step Tutorial](https://antonputra.com/aws-session-manager-tutorial/)
