# Kubernetes Continuous Delivery with Flux v2:  AWS | EKS | ECR | CD Pipeline | Fluxcd | GitOps

[YouTube Tutorial](https://youtu.be/X9R5ySkiUkc)
