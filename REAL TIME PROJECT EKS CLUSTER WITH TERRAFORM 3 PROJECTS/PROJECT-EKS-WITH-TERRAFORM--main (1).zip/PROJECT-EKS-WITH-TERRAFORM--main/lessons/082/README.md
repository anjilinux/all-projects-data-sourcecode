# NGINX Ingress Controller for Kubernetes Tutorial

You can find tutorial [here](https://antonputra.com/kubernetes/nginx-ingress-controller/).
